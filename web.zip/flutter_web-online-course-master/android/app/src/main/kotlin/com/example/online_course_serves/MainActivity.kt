package com.example.online_course_serves

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
